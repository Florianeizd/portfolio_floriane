-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : mer. 05 mai 2021 à 09:29
-- Version du serveur :  5.7.11
-- Version de PHP : 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `fleam_site2`
--

-- --------------------------------------------------------

--
-- Structure de la table `actualite`
--

CREATE TABLE `actualite` (
  `id_actualite` varchar(50) NOT NULL,
  `titre_jeux` varchar(50) DEFAULT NULL,
  `date_news` date DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `photoactu` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `actualite`
--

INSERT INTO `actualite` (`id_actualite`, `titre_jeux`, `date_news`, `note`, `photoactu`) VALUES
('1', 'The Last of Us Part II', '2021-04-21', 'Rakuten propose actuellement une série de rabais, The Last of Us Part II n\'est pas passé à côté ! Il est ainsi proposé à moins de 25€ ! Pensez à ajouter le code RAKUTEN5 afin de bénéficier de l\'offre !', 'the.jpg'),
('2', 'F1 2021', '2021-04-28', 'Codemasters s\'est enfin décidé à officialiser le développement de F1 2021 sur consoles et PC. Et visiblement, les rumeurs avaient vu juste.', 'F1.jpg'),
('3', 'Battlefield 6 ', '2021-04-29', 'C\'est par le biais d\'un communiqué officiel que DICE a exposé ses plans pour sa série phare Battlefield.', 'Bat.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `pseudoU` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `aimer`
--

CREATE TABLE `aimer` (
  `Id_jeux` varchar(50) NOT NULL,
  `pseudoU` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `droit`
--

CREATE TABLE `droit` (
  `id_privilege` int(11) NOT NULL,
  `nom` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `jeux_videos`
--

CREATE TABLE `jeux_videos` (
  `Id_jeux` varchar(50) NOT NULL,
  `nom` varchar(50) DEFAULT NULL,
  `date_sortie` date DEFAULT NULL,
  `description` text,
  `prix_officiel` varchar(50) DEFAULT NULL,
  `cheminphoto` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `jeux_videos`
--

INSERT INTO `jeux_videos` (`Id_jeux`, `nom`, `date_sortie`, `description`, `prix_officiel`, `cheminphoto`) VALUES
('1', 'Minecraft', '2011-11-18', 'Minecraft est un jeu qui consiste à placer des blocs et à partir dans des aventures en solo ou multijoueur. ', '23,95', 'Min.jpg'),
('10', 'League of Legends', '2009-10-27', 'League of Legends est un jeu de stratégie en équipe dans lequel deux équipes de cinq champions s\'affrontent pour détruire la base adverse. Faites votre choix parmi plus de 140 champions disponibles, partez au combat, éliminez vos adversaires avec adresse et abattez les tourelles ennemies pour décrocher la victoire. ', 'Gratuit', 'Lea.jpg'),
('11', 'ARK : Survival Evolved', '2016-09-01', 'ARK : Survival Evolved est un jeu de survie en vue à la première personne. Le joueur doit évoluer sur une île sauvage où les dinosaures dominent. ', '23,68', 'Ark.jpg'),
('12', ' Rocket League', '2015-07-07', 'Jeu de d\'action et de sport, Rocket League vous plonge dans dans des matchs d\'arène où votre but sera de marquer des buts. Vous pourrez mettre au point différentes tactiques, soit éviter les attaques des joueurs ennemis pour aller marquer, soit démolir la défense. ', '14,94', 'Roc.jpg'),
('13', 'Les Sims 4', '2014-09-04', 'Les Sims 4 est une simulation de vie qui permet au joueur de créer ses personnages et de les faire évoluer dans un univers qu\'il customise lui-même.', '18,40', 'Sim.jpg'),
('14', 'Among Us', '2018-06-15', 'Among Us est un party-game spatial jouable de 4 à 10 joueurs. Dans une station spatiale, il y a un imposteur caché parmi l\'équipage dont la mission est d\'assassiner les autres joueurs sans se faire prendre.', '3,99', 'Amo.jpg'),
('15', 'Fall Guys : Ultimate Knockout', '2020-08-04', 'Fall Guys : Ultimate Knockout réunit 60 participants en ligne dans une course chaotique et effrénée qui ne couronnera qu’un seul gagnant. Les obstacles étranges, le manque de discipline des concurrents et les lois inflexibles de la physique se dressent sur la route du succès de cet intervilles moderne .', '19,99', 'Fal.jpg'),
('2', 'The Crew 2', '2018-05-31', 'The Crew 2 est un gigantesque terrain de jeu en monde ouvert, pensé pour les sports mécaniques et vous mettant aux commandes de voitures, motos, bateaux et avions.', '49,99', 'Cre.jpg'),
('3', 'GTA V', '2013-09-17', 'GTA 5 est un jeu vidéo d\'aventure et d\'action qui consiste à faire des missions, des courses et plein d\'autres activités pour gagner de l\'argent et s\'acheter des appartements, des maisons, des voitures ou des avions...', '19,99', 'Gta.jpg'),
('4', 'Cyberpunk 2077', '2020-12-10', 'Cyberpunk 2077 est un jeu de rôle futuriste, dans un monde devenu indissociable de la cybernétique, l\'indépendance des robots humanoïdes qui pose quelques problèmes...', '29,90', 'Cyb.jpg'),
('5', 'Call of Duty : Black Ops Cold War', '2020-11-13', 'Call of Duty : Black Ops Cold War est un jeu de tir à la première personne. Le joueur est plongé dans les profondeurs de la Guerre Froide au début des années 1980.', '59,99', 'Cal.jpeg'),
('6', 'FIFA 2021', '2020-10-09', ' FIFA 21 est une simulation de football éditée par Electronic Arts. Comme chaque année, le jeu promet des améliorations techniques pour toujours plus de réalisme ainsi que des animations et des comportements toujours plus poussés. ', '24,90', 'Fif.jpg'),
('7', 'Genshin Impact', '2020-09-28', ' Genshin Impact, un action RPG en monde ouvert. Le monde de Teyvat est un endroit rempli de magie, où des quêtes épiques ne demandent qu’à être entreprise.', 'Gratuit', 'Gen.jpeg'),
('8', 'Assassin\'s Creed Valhalla', '2020-11-10', 'Assassin\'s Creed Valhalla est un RPG en monde ouvert se déroulant pendant l\'âge des vikings. Vous incarnez Eivor, un viking du sexe de votre choix qui a quitté la Norvège pour trouver la fortune et la gloire en Angleterre.', '59,99', 'Ass.jpg'),
('9', 'Valorant', '2020-06-02', 'Valorant est un FPS tactique. Le jeu propose de nombreux personnages aux capacités uniques et différents modes de jeu. ', 'Gratuit', 'Val.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `mon_compte`
--

CREATE TABLE `mon_compte` (
  `pseudoU` varchar(50) NOT NULL,
  `mdpU` varchar(50) DEFAULT NULL,
  `adminU` tinyint(1) DEFAULT NULL,
  `mailU` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `mon_compte`
--

INSERT INTO `mon_compte` (`pseudoU`, `mdpU`, `adminU`, `mailU`) VALUES
('fofo', 'faufau', 0, 'fofo'),
('test', 'flo', 1, 'test'),
('test2', 'test', 0, 'test2@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `non_admin`
--

CREATE TABLE `non_admin` (
  `pseudoU` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `posseder`
--

CREATE TABLE `posseder` (
  `pseudoU` varchar(50) NOT NULL,
  `id_privilege` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `rajouter`
--

CREATE TABLE `rajouter` (
  `id_actualite` varchar(50) NOT NULL,
  `pseudoU` varchar(50) NOT NULL,
  `date_ajout` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `test`
--

CREATE TABLE `test` (
  `id_test` int(11) NOT NULL,
  `avis` varchar(50) DEFAULT NULL,
  `pseudoU` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `actualite`
--
ALTER TABLE `actualite`
  ADD PRIMARY KEY (`id_actualite`);

--
-- Index pour la table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`pseudoU`);

--
-- Index pour la table `aimer`
--
ALTER TABLE `aimer`
  ADD PRIMARY KEY (`Id_jeux`,`pseudoU`),
  ADD KEY `id_utilisateurs` (`pseudoU`);

--
-- Index pour la table `droit`
--
ALTER TABLE `droit`
  ADD PRIMARY KEY (`id_privilege`);

--
-- Index pour la table `jeux_videos`
--
ALTER TABLE `jeux_videos`
  ADD PRIMARY KEY (`Id_jeux`);

--
-- Index pour la table `mon_compte`
--
ALTER TABLE `mon_compte`
  ADD PRIMARY KEY (`pseudoU`);

--
-- Index pour la table `non_admin`
--
ALTER TABLE `non_admin`
  ADD PRIMARY KEY (`pseudoU`);

--
-- Index pour la table `posseder`
--
ALTER TABLE `posseder`
  ADD PRIMARY KEY (`pseudoU`,`id_privilege`),
  ADD KEY `id_privilege` (`id_privilege`);

--
-- Index pour la table `rajouter`
--
ALTER TABLE `rajouter`
  ADD PRIMARY KEY (`id_actualite`,`pseudoU`),
  ADD KEY `id_utilisateurs` (`pseudoU`);

--
-- Index pour la table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`id_test`),
  ADD KEY `id_utilisateurs` (`pseudoU`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `admin`
--
ALTER TABLE `admin`
  ADD CONSTRAINT `admin_ibfk_1` FOREIGN KEY (`pseudoU`) REFERENCES `mon_compte` (`pseudoU`);

--
-- Contraintes pour la table `aimer`
--
ALTER TABLE `aimer`
  ADD CONSTRAINT `aimer_ibfk_1` FOREIGN KEY (`Id_jeux`) REFERENCES `jeux_videos` (`Id_jeux`),
  ADD CONSTRAINT `aimer_ibfk_2` FOREIGN KEY (`pseudoU`) REFERENCES `mon_compte` (`pseudoU`);

--
-- Contraintes pour la table `non_admin`
--
ALTER TABLE `non_admin`
  ADD CONSTRAINT `non_admin_ibfk_1` FOREIGN KEY (`pseudoU`) REFERENCES `mon_compte` (`pseudoU`);

--
-- Contraintes pour la table `posseder`
--
ALTER TABLE `posseder`
  ADD CONSTRAINT `posseder_ibfk_1` FOREIGN KEY (`pseudoU`) REFERENCES `mon_compte` (`pseudoU`),
  ADD CONSTRAINT `posseder_ibfk_2` FOREIGN KEY (`id_privilege`) REFERENCES `droit` (`id_privilege`);

--
-- Contraintes pour la table `rajouter`
--
ALTER TABLE `rajouter`
  ADD CONSTRAINT `rajouter_ibfk_1` FOREIGN KEY (`id_actualite`) REFERENCES `actualite` (`id_actualite`),
  ADD CONSTRAINT `rajouter_ibfk_2` FOREIGN KEY (`pseudoU`) REFERENCES `admin` (`pseudoU`);

--
-- Contraintes pour la table `test`
--
ALTER TABLE `test`
  ADD CONSTRAINT `test_ibfk_1` FOREIGN KEY (`pseudoU`) REFERENCES `non_admin` (`pseudoU`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
