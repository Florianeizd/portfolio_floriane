<?php
include_once "./modele/jeux_videosDAO.php";

$ret= jeux_videosDAO::creejeux_videos();

include "./vue/entete.html.php";
include "./vue/vuejeux_videos.html.php";

?>
