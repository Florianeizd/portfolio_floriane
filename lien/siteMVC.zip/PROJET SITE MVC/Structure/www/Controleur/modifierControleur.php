<?php
include_once "./Modele/bd.utilisateur.inc.php";

if (isset($_POST["pseudoU"]) && isset($_POST["mdpU"])){
    $pseudoU = $_POST["pseudoU"];
    $mdpU = $_POST["mdpU"];
    $ret = utilisateurDAO::modifierutilisateur($pseudoU, $mdpU);

}

include "./Vue/entete.html.php";

if($ret!=NULL){
    include "./Vue/vuemon_compte.html.php";
}else{
    include "./Vue/vuemodifierutilisateur.php";
}