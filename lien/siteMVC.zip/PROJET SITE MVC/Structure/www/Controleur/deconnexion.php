<?php

include_once "./modele/authentification.inc.php";


logout();

                

// appel du script de vue qui permet de gerer l'affichage des donnees
$titre = "authentification";
include "./vue/entete.html.php";
include "./vue/vueAuthentification.php";



?>