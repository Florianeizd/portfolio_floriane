<?php

function controleurPrincipal($action) {
    $lesActions = array();
    $lesActions["defaut"] = "actualiteControleur.php";
    $lesActions["jeux_videos"] = "jeux_videosControleur.php";
    $lesActions["mon_compte"] = "mon_compteControleur.php";
    $lesActions["inscription"] = "inscription.php";
    $lesActions["connexion"] = "connexion.php";
    $lesActions["deconnexion"] = "deconnexion.php";
    $lesActions["profil"] = "monProfil.php";
    $lesActions["supprimer"] = "supprimerControleur.php";
    $lesActions["modifier"] = "modifierControleur.php";

    if (array_key_exists($action, $lesActions)) {
        return $lesActions[$action];
    } 
    else {
        return $lesActions["defaut"];
    }
}

?>