<?php 

include_once "./Modele/bd.utilisateur.inc.php";
if (isset($_GET["pseudoU"])){
    $pseudoU = $_GET["pseudoU"];
}

utilisateurDAO::deleteutilisateur($pseudoU);

if(utilisateurDAO::deleteutilisateur($pseudoU)){
    include "./Vue/entete.html.php";
    include "./Vue/vuemon_compte.html.php";
}else{
    print "Votre compte n'a pas été supprimé";
}