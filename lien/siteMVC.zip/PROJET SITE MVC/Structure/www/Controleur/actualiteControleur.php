<?php
include_once "./modele/actualiteDAO.php";

$ret= actualiteDAO::creeactualite();

include "./vue/entete.html.php";
include "./vue/vueactualite.html.php";
