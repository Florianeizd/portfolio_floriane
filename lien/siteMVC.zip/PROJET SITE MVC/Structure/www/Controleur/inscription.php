<?php

include_once "./modele/bd.utilisateur.inc.php";

$inscrit = false;
// recuperation des donnees GET, POST, et SESSION
if (isset($_POST["pseudoU"]) && isset($_POST["mdpU"]) && isset($_POST["mailU"])) {

    if ($_POST["pseudoU"] != "" && $_POST["mdpU"] != "" && $_POST["mailU"] != "") {
        $pseudoU = $_POST["pseudoU"];
        $mdpU = $_POST["mdpU"];
        $mailU = $_POST["mailU"];

        // enregistrement des donnees
        $ret = utilisateurDAO::addUtilisateur($pseudoU, $mdpU, $adminU,$mailU);
        if ($ret) {
            $inscrit = true;
        } else {
            $msg = "l'utilisateur n'a pas été enregistré.";
        }
    }
 else {
    $msg="Renseigner tous les champs...";    
    }
}

if ($inscrit) {
    // appel du script de vue qui permet de gerer l'affichage des donnees
    $titre = "Inscription confirmée";
    include "./vue/entete.html.php";
    include "./vue/vueConfirmationInscription.php";
} else {
    // appel du script de vue qui permet de gerer l'affichage des donnees
    $titre = "Inscription pb";
    include "./vue/entete.html.php";
    include "./vue/vueInscription.php";

}
?>