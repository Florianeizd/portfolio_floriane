<?php

include_once "./Modele/authentification.inc.php";

// recuperation des donnees GET, POST, et SESSION
if (isset($_POST["pseudoU"]) && isset($_POST["mdpU"])&& isset($_POST["mailU"])){
    $pseudoU=$_POST["pseudoU"];
    $mdpU=$_POST["mdpU"]; 
    $mailU=$_POST["mailU"];
}
else
{

    $pseudoU="";
    $mdpU="";    
    $mailU="";

}

if($mailU != "" && $pseudoU !=""){
    login($pseudoU, $mdpU, $mailU);
}
   
if(isLoggedOn()){
    include "./Controleur/monProfilControleur.php";
}else{
    include "./vue/entete.html.php";
    include "./vue/vuemon_compte.html.php";
}


?>