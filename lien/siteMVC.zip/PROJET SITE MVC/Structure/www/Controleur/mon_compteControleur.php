<?php
include_once "./modele/bd.utilisateur.inc.php";

$ret= utilisateurDAO::getUtilisateurs();

include "./vue/entete.html.php";
include "./vue/vuemon_compte.html.php";

?>