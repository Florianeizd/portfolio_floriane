<?php
include_once "./Modele/bd.utilisateur.inc.php";
include_once "./Modele/authentification.inc.php";

$ret = utilisateurDAO::creeutilisateur();

include "./vue/entete.html.php";
include "./vue/vueMonProfil.php";