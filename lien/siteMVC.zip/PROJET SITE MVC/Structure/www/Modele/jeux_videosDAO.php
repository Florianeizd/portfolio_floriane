<?php

include_once "jeux_videos.php";
include_once "bd.inc.php";

class jeux_videosDAO{
    public static function creejeux_videos(){
        $resultat = array();

        try{
            $cnx = connexionPDO();
            $req = $cnx->prepare("select * from jeux_videos");
            $req->execute();

            $ligne = $req->fetch(PDO::FETCH_ASSOC);
            while ($ligne) {
                $resultat[]=new jeux_videos($ligne["id_jeux"], $ligne["nom"], $ligne["date_sortie"], $ligne["description"], $ligne["prix_officiel"], $ligne["cheminphoto"]);
                $ligne=$req->fetch(PDO::FETCH_ASSOC);
            }
        } catch (PDOException $e){
            print "Erreur ! : " .$e->getMessage();
            die();
        }
        return $resultat;
    }

}