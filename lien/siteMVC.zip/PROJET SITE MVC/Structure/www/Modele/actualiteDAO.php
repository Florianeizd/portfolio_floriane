<?php
include_once "actualite.php";
include_once "bd.inc.php";

class actualiteDAO{
    public static function creeactualite(){
        $resultat = array();

        try{
            $cnx = connexionPDO();
            $req = $cnx->prepare("select * from actualite");
            $req->execute();

            $ligne = $req->fetch(PDO::FETCH_ASSOC);
            while ($ligne) {
                $resultat[]=new actualite($ligne["id_actualite"], $ligne["titre_jeux"], $ligne["date_news"], $ligne["note"], $ligne["photoactu"]);
                $ligne=$req->fetch(PDO::FETCH_ASSOC);
            }
        } catch (PDOException $e){
            print "Erreur ! : " .$e->getMessage();
            die();
        }
        return $resultat;
    }
}