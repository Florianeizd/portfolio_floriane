<?php

// include_once "bd.inc.php";

// class test{
//     private $id_test;
//     private $avis;

//     public function __construct($idtest, $unavis){
//         $this->id_test=$idtest;
//         $this->avis=$unavis;
//     }
// }