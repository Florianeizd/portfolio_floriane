<?php

class mon_compte{
    private $pseudoU;
    private $mdpU; 
    private $adminU;
    private $mailU;
   

    public function __construct($unpseudo, $unmdp, $unmail){
        $this->pseudoU=$unpseudo;
        $this->mdpU=$unmdp;
        $this->mailU=$unmail;
    }
    public function getpseudo(){
        return $this->pseudoU;
    }
    public function getmdp(){
        return $this->mdpU;
    }
    public function getadmin(){  //FAIRE UN IF POUR SAVOIR SI ADMIN OU NON
        return $this->adminU;
    }
    public function getmail(){
        return $this->mailU;
    }
    
    
}