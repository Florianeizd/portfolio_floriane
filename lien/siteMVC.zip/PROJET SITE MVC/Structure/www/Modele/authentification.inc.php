<?php

include_once "bd.utilisateur.inc.php";


function login($pseudoU,$mdpU, $mailU) {
    if (!isset($_SESSION)) {
        session_start();
    }

    $util = utilisateurDAO::getUtilisateurByMailU($mailU);
    $pseudoBd = $util ["pseudoU"];
    $mdpBD = $util["mdpU"];

    if ($mdpBD == $mdpU && $pseudoBd == $pseudoU) {
        // le mot de passe est celui de l'utilisateur dans la base de donnees
        $_SESSION["pseudoU"]= $pseudoU;
        $_SESSION["mdpU"] = $mdpBD;
        $_SESSION["mailU"] = $mailU;
    }
}

function logout() {
    if (!isset($_SESSION)) {
        session_start();
    }
    unset($_SESSION["pseudoU"]);
    unset($_SESSION["mdpU"]);
    unset($_SESSION["mailU"]);
}

function getMailULoggedOn(){
    if (isLoggedOn()){
        $ret = $_SESSION["mailU"];
    }
    else {
        $ret = "";
    }
    return $ret;
        
}

function isLoggedOn() {
    if (!isset($_SESSION)) {
        session_start();
    }
    $ret = false;

    if (isset($_SESSION["mailU"])) {
        $util = utilisateurDAO::getUtilisateurByMailU($_SESSION["mailU"]);
        if ($util["pseudoU"] == $_SESSION["pseudoU"] && $util["mdpU"] == $_SESSION["mdpU"] && $util["mailU"] == $_SESSION["mailU"]) {
            $ret = true;
        }
    }
    return $ret;
}


?>