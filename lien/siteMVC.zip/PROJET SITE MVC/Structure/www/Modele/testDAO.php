<?php

// include_once "test.php";

// class testDAO{
//     public function test(){
//         $resultat = array();

//         try{
//             $cnx = connexionPDO();
//             $req = $cnx->prepare("select * from test");
//             $req->execute();

//             $ligne = $req->fetch(PDO::FETCH_ASSOC);
//             while ($ligne) {
//                 $resultat[]=new test($ligne["id_test"], $ligne["avis"]);
//                 $ligne=$req->fetch(PDO::FETCH_ASSOC);
//             }
//         } catch (PDOException $e){
//             print "Erreur ! : " .$e->getMessage();
//             die();
//         }
//         return $resultat;
//     }
// }