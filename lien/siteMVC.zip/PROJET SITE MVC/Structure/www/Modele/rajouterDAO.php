<?php

// include_once "rajouter.php";

// class rajouterDAO{
//     public function rajouter(){
//         $resultat = array();

//         try{
//             $cnx = connexionPDO();
//             $req = $cnx->prepare("select * from rajouter");
//             $req->execute();

//             $ligne = $req->fetch(PDO::FETCH_ASSOC);
//             while ($ligne) {
//                 $resultat[]=new rajouter($ligne["date_ajout"]);
//                 $ligne=$req->fetch(PDO::FETCH_ASSOC);
//             }
//         } catch (PDOException $e){
//             print "Erreur ! : " .$e->getMessage();
//             die();
//         }
//         return $resultat;
//     }
// }