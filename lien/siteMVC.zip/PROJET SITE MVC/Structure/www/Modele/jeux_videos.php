<?php

class jeux_videos{
    private $id_jeux;
    private $nom;
    private $date_sortie;
    private $description;
    private $prix_officiel;
    private $cheminphoto;
    
    public function __construct($idjeux, $unnom, $unedatesortie, $unedescription, $unprixofficiel, $unchemin){
        $this->id_jeux=$idjeux;
        $this->nom=$unnom;
        $this->date_sortie=$unedatesortie;
        $this->description=$unedescription;
        $this->prix_officiel=$unprixofficiel;
        $this->cheminphoto=$unchemin;

    }

    public function getchemin(){
        return $this->cheminphoto;
    }

    public function getnom(){
        return $this->nom;
    }
    
    public function getdatesortie(){
        return $this->date_sortie;
    }
    public function getdescription(){
        return $this->description;
    }
    public function getprixofficiel(){
        return $this->prix_officiel;
    }
}