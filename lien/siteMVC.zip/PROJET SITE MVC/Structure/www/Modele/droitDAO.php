<?php

// include_once "droit.php";

// class droitDAO{
//     public function droit(){
//         $resultat = array();

//         try{
//             $cnx = connexionPDO();
//             $req = $cnx->prepare("select * from droit");
//             $req->execute();

//             $ligne = $req->fetch(PDO::FETCH_ASSOC);
//             while ($ligne) {
//                 $resultat[]=new droit($ligne["id_privilege"], $ligne["nom"]);
//                 $ligne=$req->fetch(PDO::FETCH_ASSOC);
//             }
//         } catch (PDOException $e){
//             print "Erreur ! : " .$e->getMessage();
//             die();
//         }
//         return $resultat;
//     }
// }