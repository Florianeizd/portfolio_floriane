<?php

// include_once "bd.inc.php";

// class droit{
//     private $id_privilege;
//     private $nom;

//     public function __construct($idprivilege, $unnom){
//         $this->id_privilege=$idprivilege;
//         $this->nom=$unnom;
//     }
// }