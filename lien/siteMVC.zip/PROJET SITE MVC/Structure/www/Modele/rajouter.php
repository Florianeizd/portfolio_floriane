<?php

// include_once "bd.inc.php";

// class rajouter{
//     private $date_ajout;

//     public function __construct($unedateajout){
//         $this->date_ajout=$unedateajout;
//     }
// }