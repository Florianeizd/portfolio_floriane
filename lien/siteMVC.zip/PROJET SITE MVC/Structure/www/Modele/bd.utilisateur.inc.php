<?php

include_once "bd.inc.php";
include_once "mon_compte.php";
include_once "./Modele/authentification.inc.php";

class utilisateurDAO{
    public static function creeutilisateur(){
        $resultat = array();

        try{
            $cnx = connexionPDO();
            $req = $cnx->prepare("select * from mon_compte");
            $req->execute();

            $ligne = $req->fetch(PDO::FETCH_ASSOC);
            while ($ligne) {
                $resultat[]=new mon_compte($ligne["pseudoU"], $ligne["mdpU"], $ligne["mailU"]);
                $ligne=$req->fetch(PDO::FETCH_ASSOC);
            }
        } catch (PDOException $e){
            print "Erreur ! : " .$e->getMessage();
            die();
        }
        return $resultat;
    }

    public static function getUtilisateurs() {

        try {
            $cnx = connexionPDO();
            $req = $cnx->prepare("select * from mon_compte");
            $req->execute();

            $ligne = $req->fetch(PDO::FETCH_ASSOC);
            while ($ligne) {
                $resultat[] = $ligne;
                $ligne = $req->fetch(PDO::FETCH_ASSOC);
            }
        } catch (PDOException $e) {
            print "Erreur !: " . $e->getMessage();
            die();
        }
        return $resultat;
    }   

    public static function getUtilisateurByMailU($mailU) {

        try {
            $cnx = connexionPDO();
            $req = $cnx->prepare("select * from mon_compte where mailU=:mailU");
            $req->bindValue(':mailU', $mailU, PDO::PARAM_STR);
            $req->execute();
        
            $resultat = $req->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            print "Erreur !: " . $e->getMessage();
            die();
        }
        return $resultat;
    }

    public static function getmailUloggedOn($mailU) {
        if (isLoggedOn()){
            $ret = $_SESSION["mailU"];
        }
        else {
            $ret = "";
        }
        return $ret;

    }



    public static function getpseudoUloggedOn($pseudoU) {
        if (isLoggedOn()){
            $ret = $_SESSION["pseudoU"];
        }
        else {
            $ret = "";
        }
        return $ret;

    }



    public static function addUtilisateur($pseudoU, $mdpU, $adminU, $mailU) {
        try {
            $cnx = connexionPDO();

            $req = $cnx->prepare("insert into mon_compte (pseudoU,mdpU, adminU, mailU) values(:pseudoU,:mdpU, :adminU, :mailU)");
            $req->bindValue(':pseudoU', $pseudoU, PDO::PARAM_STR);
            $req->bindValue(':mdpU', $mdpU, PDO::PARAM_STR);
            $req->bindValue(':adminU', $adminU, PDO::PARAM_STR);
            $req->bindValue(':mailU', $mailU, PDO::PARAM_STR);
        
            $resultat = $req->execute();
        } catch (PDOException $e) {
            print "Erreur !: " . $e->getMessage();
            die();
        }
        return $resultat;
    }

    public static function deleteutilisateur($pseudoU){
        $resultat =-1;
        try {
            $cnx = connexionPDO();

            $req = $cnx->prepare("delete from mon_compte where pseudoU=:pseudoU");
            $req->bindValue(':pseudoU', $pseudoU, PDO::PARAM_STR);
            $resultat = $req->execute();
        } catch (PDOException $e) {
            print "Erreur !: " . $e->getMessage();
            die();
        }
        return $resultat;

    }
    public static function modifierutilisateur($pseudoU, $mdpU){
        try {
            $cnx = connexionPDO();

            $req = $cnx->prepare("update mon_compte set mdpU=:mdpU where pseudoU=:pseudoU");
            $req->bindValue(':mdpU', $mdpU, PDO::PARAM_STR);
            $req->bindValue(':pseudoU', $pseudoU, PDO::PARAM_STR);
            $resultat = $req->execute();
        } catch (PDOException $e) {
            print "Erreur !: " . $e->getMessage();
            die();
        }
        return $resultat;

    }

}
