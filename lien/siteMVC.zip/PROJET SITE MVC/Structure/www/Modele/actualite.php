<?php

include_once "bd.inc.php";

class actualite{
    private $id_actualite;
    private $titre_jeux;
    private $date_news;
    private $note;
    private $photoactu;

    public function __construct($idactu, $untitrejeux, $unedatenews, $unenote, $unephotoactu){
        $this->id_actualite=$idactu;
        $this->titre_jeux=$untitrejeux;
        $this->date_news=$unedatenews;
        $this->note=$unenote;
        $this->photoactu=$unephotoactu;
    }
    public function gettitrejeux(){
        return $this->titre_jeux;
    }
    public function getdatenews(){
        return $this->date_news;
    }
    public function getnote(){
        return $this->note;
    }

    public function getphotoact(){
        return $this->photoactu;
    }
}