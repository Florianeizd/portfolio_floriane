<html>

    <body>
    <center>
        <U><h2>Modifier mon compte  </h2></U>
    <?php echo "<form action='./?action=modifier","'method='POST'>"?>


    <input type="text" name="pseudoU" id="pseudoU" placeholder="Pseudo" /><br><br>

    <input type="password" name="mdpU" id="mdpU" placeholder="Mot de passe"  /><br><br>

    <input type="submit" />
    </form>
  
    </center>
    </body>
</html>