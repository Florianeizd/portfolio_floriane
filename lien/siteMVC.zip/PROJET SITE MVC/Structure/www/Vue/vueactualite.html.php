<html>
    <head>
    <link rel="stylesheet" href="./Css/jeux_videos.css" />
    </head>

    <body>
        <center>
            <U><h2>L'actualité </h2></U>
        </center>
        <?php
        $i=0;
        while($ret[$i]){
        ?>
        <html>
        <center>
        <div class="cards">
        <article class="card">
        <header> 
        <h3><?= $ret[$i]->gettitrejeux()?></h3>
        <img src="./image/actu/<?=$ret[$i]->getphotoact()?>"width="500"/>
        </header>
        <div class="content">
        <p>Publié le : <?= $ret[$i]->getdatenews()?></p>
        <p>Description : <?= $ret[$i]->getnote()?></p>      
        </div>
            <footer></footer>
        </article>
        </div>
        </center>  
        </html>
        <?php
        $i++;
    }
    ?>
    </body>
</html>