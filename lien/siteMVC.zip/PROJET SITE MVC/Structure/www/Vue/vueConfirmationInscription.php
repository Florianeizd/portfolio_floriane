<html>
<h1>Vous êtes inscrit ! </h1>