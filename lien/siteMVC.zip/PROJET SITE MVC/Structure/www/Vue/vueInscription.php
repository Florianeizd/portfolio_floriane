<html>
    <body>
    <center>
        <U><h2>Inscription  </h2></U>

    <form action="./?action=inscription" method="POST">
    <input type="text" name="mailU" placeholder="Mail de connexion" /><br><br>
    <input type="text" name="pseudoU" placeholder="Pseudo" /><br><br>
    <input type="password" name="mdpU" placeholder="Mot de passe"  /><br><br>
    <input type="submit" />
    </form>
    </center>
    </body>
</html>