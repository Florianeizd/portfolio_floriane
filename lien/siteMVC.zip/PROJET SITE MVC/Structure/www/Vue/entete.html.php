<html>
    <head>
        <meta charset="UTF-8" />
        <link rel="stylesheet" href="./Css/base.css" />
    </head>

<body>
 <div id="page">
    <ul id="header">
        <img src="./image/Photos/logo2.png" width="50"/>
  <li><a href="./?action=Fleam">Fleam</a></li>
  <li><a href="./?action=actualite">Actualité</a></li>
  <li><a href="./?action=jeux_videos">Jeux Vidéos</a></li>
  <li><a href="./?action=connexion">Mon Compte</a></li>
     </ul>
 
    <div id="contenu"></div>
 
    <div id="footer"></div>
 </div>
</body>

</html>