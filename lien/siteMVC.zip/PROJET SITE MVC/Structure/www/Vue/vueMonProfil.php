<html>
<h1>Vous êtes connecté ! </h1>
<h2>Mon profil :</h2>


Mon mail : <?= utilisateurDAO::getmailUloggedOn($mailU); ?><br><br /> 
Mon pseudo : <?= utilisateurDAO::getpseudoUloggedOn($pseudoU); ?><br><br />


<a href=<?php echo "./?action=supprimer&pseudoU=".$_SESSION["pseudoU"]?>>Supprimer mon compte</a><br><br/>
<a href="./?action=deconnexion">se deconnecter</a><br><br/>
<a href="./?action=modifier">modifier</a>

</html>
