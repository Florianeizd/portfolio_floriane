<html>
    <head>
    <link rel="stylesheet" href="./Css/jeux_videos.css" />
    </head>

    <body>
        <center>
           <br> <U><h2>Les Jeux Vidéos  </h2></U>
        </center>
        <?php
        $i=0;
        while($ret[$i]){
        ?>
        <html>
        <center>
        <div class="cards">
        <article class="card">
            <header> 
            <h3><?= $ret[$i]->getnom()?></h3>
            <img src="./image/jeux/<?=$ret[$i]->getchemin()?>" width="500"/>
            
            </header>
            <div class="content">
            <p>Date de sortie : <?= $ret[$i]->getdatesortie()?></p>
            <p>Description : <?= $ret[$i]->getdescription()?></p>      
            <p>Prix officiel : <?= $ret[$i]->getprixofficiel()?></p>
            </div>
            <footer></footer>
        </article>
        </div>
        </center> 
        </html>
        <?php
        $i++;
    }
    ?>
    </body>
</html>