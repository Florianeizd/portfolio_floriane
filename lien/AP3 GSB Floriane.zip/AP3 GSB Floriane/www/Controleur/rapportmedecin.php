<?php
include_once './Modele/medecinDAO.php';
include_once "./Modele/authentification.inc.php";
include_once './Modele/medecin.php';
include_once './Modele/rapportDAO.php';
include_once './Modele/rapport.php';

if (isset($_GET["idMedecin"])){
    $idMedecin = $_GET["idMedecin"];
    $ret=rapportDAO::getrapportmedecin($idMedecin);

}

include "./Vue/entete.html.php";
include "./Vue/rapportmedecin.html.php";