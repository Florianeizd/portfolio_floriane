<?php

function controleurPrincipal($action) {
    $lesActions = array();
    $lesActions["defaut"] = "monProfilControleur.php";
    $lesActions["visiteur"] = "visiteurControleur.php";
    $lesActions["mon_compte"] = "mon_compteControleur.php";
    $lesActions["creerapport"] = "creerapport.php";
    $lesActions["connexion"] = "connexion.php";
    $lesActions["deconnexion"] = "deconnexion.php";
    $lesActions["profil"] = "monProfil.php";
    $lesActions["modifiermedecin"] = "modifiermedecin.php";
    $lesActions["modifierrapport"] = "modifierrapport.php";
    $lesActions["rapport"] = "rapport.php";
    $lesActions["medecin"] = "medecin.php";
    $lesActions["SearchMedecin"] = "searchmedecin.php";
    $lesActions["rapportmedecin"] = "rapportmedecin.php";
    $lesActions["medicament"] = "medicament.php";
    $lesActions["listerapports"] = "listerapports.php";
    $lesActions["enrmodmedecin"] = "enrmodmedecin.php";
    $lesActions["enrmodrapport"] = "enrmodrapport.php";
    $lesActions["SearchRapport"] = "searchrapport.php";
    $lesActions["CreeRapportMed"] = "rapportetape.php";

    if (array_key_exists($action, $lesActions)) {
        return $lesActions[$action];
    } 
    else {
        return $lesActions["defaut"];
    }
}

?>