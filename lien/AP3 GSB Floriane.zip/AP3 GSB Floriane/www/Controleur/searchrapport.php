<?php
include_once "./Modele/authentification.inc.php";
include_once "./Modele/bd.utilisateur.inc.php";
include_once "./Modele/medecinDAO.php";
include_once "./Modele/medecin.php";
include_once "./Modele/rapportDAO.php";
include_once "./Modele/rapport.php";

if (isset($_POST["date"])){
    $date=$_POST["date"];
    $lesrapports = rapportDAO::searchrapport($date);
}
$lesrapports = rapportDAO::searchrapport($date);
$ret= array();

include "./Vue/entete.html.php";
include "./Vue/vuelisterapports.html.php";