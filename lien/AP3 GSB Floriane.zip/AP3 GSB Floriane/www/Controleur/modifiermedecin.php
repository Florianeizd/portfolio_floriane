<?php

include_once "./Modele/authentification.inc.php";
include_once "./Modele/bd.utilisateur.inc.php";
include_once "./Modele/medecinDAO.php";
include_once "./Modele/medecin.php";

if (isset($_GET["idMedecin"])) {
    $id = $_GET["idMedecin"];
    

}

$ret = medecinDAO::creemedecinid($id);
$lemedecin= array();

include "./Vue/entete.html.php";
include "./Vue/vuemodifiermedecin.php";