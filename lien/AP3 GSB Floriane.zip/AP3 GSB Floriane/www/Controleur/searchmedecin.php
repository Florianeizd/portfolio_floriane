<?php
include_once "./Modele/authentification.inc.php";
include_once "./Modele/bd.utilisateur.inc.php";
include_once "./Modele/medecinDAO.php";
include_once "./Modele/medecin.php";
include_once "./Modele/rapportDAO.php";
include_once "./Modele/rapport.php";

if (isset($_POST["nom"])){
    $nom=$_POST["nom"];
    $lemedecin = medecinDAO::searchmedecin($nom);
}
$lemedecin = medecinDAO::searchmedecin($nom);
$ret= array();

include "./Vue/entete.html.php";
include "./Vue/vuemedecin.html.php";
