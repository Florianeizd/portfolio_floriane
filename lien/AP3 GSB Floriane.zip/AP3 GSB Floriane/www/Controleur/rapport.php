<?php
include_once "./Modele/authentification.inc.php";
include_once "./Modele/bd.utilisateur.inc.php";
include_once "./Modele/rapportDAO.php";


$ret = rapportDAO::creerapport();

include "./Vue/entete.html.php";
include "./Vue/vuerapport.html.php";