<?php

include_once "./Modele/authentification.inc.php";
include_once "./Modele/bd.utilisateur.inc.php";
include_once "./Modele/rapportDAO.php";
include_once "./Modele/rapport.php";

if (isset($_GET["id"])) {
    $id = $_GET["id"];
    

}

$ret = rapportDAO::creerapportid($id);
$lemedecin= array();

include "./Vue/entete.html.php";
include "./Vue/vuemodifierrapport.php";