<?php 
include_once "./Modele/authentification.inc.php";
include_once "./Modele/medicamentDAO.php";
include_once "./Modele/visiteurDAO.php";
include_once "./Modele/rapportDAO.php";

$medErr="";
$listrentrermedicament=array();
$listrentrerquantite=array();
if (isset($_POST["nbMed"])){
    $nbMed=$_POST["nbMed"];
    $nbMed=intval($nbMed); //Retourne la valeur numérique entière équivalente d'une variable
    $listeMedicaments=medicamentDAO::listemedicament();
    for($i=0; $i < $nbMed; $i++){
        if (isset($_POST["medicament".$i]) && isset($_POST["quantite".$i])){
            array_push($listrentrermedicament,$_POST["medicament".$i]); //Empile un ou plusieurs éléments à la fin d'un tableau
            array_push($listrentrerquantite,$_POST["quantite".$i]);
        }
        else{
            $medErr="Tout les medicaments ne sont pas entrés";
        }
    }

    if ($medErr==""){
        $rapport=rapportDAO::getDernierRapport();
        for($i=0;$i<count($listrentrermedicament);$i++){
            medicamentDAO::addMedicament($rapport, $listrentrermedicament[$i], $listrentrerquantite[$i]);
        }
        include './Vue/entete.html.php';
        include './Vue/vueConfirmationrapport.php';
    }else{
        include './Vue/entete.html.php';
        include './Vue/ajoutermed.html.php';
    }
}else{
    include './Vue/entete.html.php';
    include './Vue/ajoutermed.html.php';
}