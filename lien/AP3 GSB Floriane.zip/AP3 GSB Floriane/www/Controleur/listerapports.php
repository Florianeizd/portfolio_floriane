<?php
include_once "./Modele/authentification.inc.php";
include_once "./Modele/bd.utilisateur.inc.php";
include_once "./Modele/rapportDAO.php";
include_once "./Modele/rapport.php";


$ret = rapportDAO::creerapport();
$lesrapports= array();

include "./Vue/entete.html.php";
include "./Vue/vuelisterapports.html.php";