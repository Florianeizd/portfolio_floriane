<?php

include_once "./Modele/bd.utilisateur.inc.php";
include_once "./Modele/medecinDAO.php";
include_once "./Modele/authentification.inc.php";

$listeMedecins=medecinDAO::getmedecin();
$inscrit = false;
// recuperation des donnees GET, POST, et SESSION

$id=authentificationDAO::getidLoggedOn();

if (isset($_POST["date"]) && isset($_POST["motif"]) && isset($_POST["bilan"]) && isset($_POST["idMedecin"]) && $id !=""  ) {
   
        $date = $_POST["date"];
        $motif = $_POST["motif"];
        $bilan = $_POST["bilan"];
        $idVisiteur = $_SESSION["id"];
        $idMedecin = $_POST["idMedecin"];

        // enregistrement des donnees
        
        $ret = visiteurDAO::addrapport( $date, $motif,$bilan, $idVisiteur, $idMedecin);
        if ($ret) {
            $inscrit = true;
        } else {
            $msg = "le rapport n'a pas été enregistré.";
        }
    }else {
    $msg="Renseigner tous les champs...";    
    }



    if ($inscrit) {
        // appel du script de vue qui permet de gerer l'affichage des donnees
        $titre = "Rapport confirmée";
        include "./Vue/entete.html.php";
        include "./Vue/nombremed.html.php";
        
    } else {
        // appel du script de vue qui permet de gerer l'affichage des donnees
        $titre = "Rapport pb";
        include "./Vue/entete.html.php";
        include "./Vue/vuecreerapport.html.php";
    
    }
?>