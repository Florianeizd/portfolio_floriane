<?php
include_once "./Modele/authentification.inc.php";
include_once "./Modele/bd.utilisateur.inc.php";
include_once "./Modele/medecinDAO.php";
include_once "./Modele/medecin.php";
include_once "./Modele/rapportDAO.php";
include_once "./Modele/rapport.php";


$ret = medecinDAO::creemedecin();
$lemedecin= array();

include "./Vue/entete.html.php";
include "./Vue/vuemedecin.html.php";