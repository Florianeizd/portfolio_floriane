<?php

include_once "./Modele/authentification.inc.php";

include_once "./Modele/rapportDAO.php";
include_once "./Modele/rapport.php";


if (isset($_POST["id"]) && isset($_POST["date"])&& isset($_POST["motif"])&& isset($_POST["bilan"])&& isset($_POST["idVisiteur"])&& isset($_POST["idMedecin"])) {
    $id = $_POST["id"];
    $date = $_POST["date"];
    $motif = $_POST["motif"];
    $bilan = $_POST["bilan"];
    $idVisiteur = $_POST["idVisiteur"];
    $idMedecin = $_POST["idMedecin"];
    $update = rapportDAO::updaterapport($id, $date, $motif, $bilan, $idVisiteur, $idMedecin);
    include "./Vue/entete.html.php";
    include "./Vue/vueconfir.html.php";

}