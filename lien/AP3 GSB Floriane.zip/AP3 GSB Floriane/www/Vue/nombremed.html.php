<html> <br>
<h1 style=" text-shadow: 2px 4px 3px rgba(0,0,0,0.3); color: #1977cc; margin-left: 60px">Création d'un rapport ! </h1><br>

        <form action="./?action=CreeRapportMed" method="post">
        <h3 style="color: #19a4cc; margin-left: 100px">Saisir le nombre de médicament</h3> <br>
        <h4 style="color: #19a4cc; margin-left: 100px">Etape 2/3</h4> <br>
        <input style="margin-left: 100px" type="number" name="nbMed" id="nbMed" class="box" placeholder="Nombre de medicament"/><br> <br>
            <button type="submit" class="btn" style=" background: #1977cc;
                            border: 0;
                            padding: 10px 35px;
                            color: #fff;
                            transition: 0.4s;
                            border-radius: 50px;
                            margin-left: 100px 
                            " >Enregistrer</button>
        </form>
        </div>
   
</html>